 
/**
 * @brief Student type store the name, id, grades of students
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**<first name of students >*/
  char last_name[50];  /**<last name of students >*/
  char id[11];  /**<10 digits student id >*/
  double *grades;  /**< an double array stores student's grades  >*/
  int num_grades;   /**<how many different grades that student have >*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
