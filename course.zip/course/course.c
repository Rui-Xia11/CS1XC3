/**
 * @file course.c
 * @author the author (you@domain.com)
 * @brief the c document of library "course .h", contain functions in library "course .h" 
 * @version 0.1
 * @date 2022-04-9
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 /**
  * @brief to enroll a new students in the course
  * 
  * @param course pointer that points to a Course type
  * @param student  the student type array that stored all students in that course
  * @return nothing
  */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); /**<dynamaically stored the new student if no students in course>*/
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); /**<dynamaically retored all previous students if there are students>*/
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief prints the info of course in a list: course name, code, and the number of students and student info.
 * 
 * @param course the pointer of a course type
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]); /**<print out each students'info>*/
}
/**
 * @brief find out the top grade students in the course 
 * 
 * @param course the pointer of a course type.
 * @return Student* the pointer of student which have top avg grade. 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; /**<if no students, return nothing>*/
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++) /**<compare students avg grade one by one>*/
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief find out students who pass the course, and provide a dynamic array that stored all students who passed. 
 * 
 * @param course the pointer of a course type.
 * @param total_passing how many students that passed, the number of passing students. 
 * @return Student* an dynamic array stored students who pass the course 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) /**<count the total number of studnets who pass >*/
    if (average(&course->students[i]) >= 50) count++; 
  
  passing = calloc(count, sizeof(Student));/**<create empty dynamic array to store info of passing students>*/

  int j = 0;
  for (int i = 0; i < course->total_students; i++) /**<store info of student who passed in array>*/
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i]; 
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}