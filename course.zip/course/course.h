/**
 * @file course.h
 * @author your name (you@domain.com)
 * @brief The .h document that 
 * @version 0.1
 * @date 2022-04-10
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
 /**
  * @brief course type stores the name, coude, students  of the course.
  * 
  */
typedef struct _course 
{
  char name[100]; /**< the name of course*/
  char code[10];  /**<  the course code */
  Student *students; /**<  students of the course  */
  int total_students; /**<  the total number of students in the course  */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


