var searchData=
[
  ['top_5fstudent_0',['top_student',['../course_8h.html#ac1d82150824c7ecd43bab36fb83cd779',1,'course.h']]],
  ['total_5fstudents_1',['total_students',['../struct__course.html#a6de820e9130cb18bb757b6f17df6c002',1,'_course']]]
];
