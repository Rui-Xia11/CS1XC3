/**
 * @file main.c
 * @author the author name (you@domain.com)
 * @brief the main function create a course MATH101 which 20 students, then print out the course info,all student info. Then find out and print the top grade student and students who passes the course .
 * @version 0.1
 * @date 2022-04-09
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course)); /**< dynamatic array that stored one course type >*/
  strcpy(MATH101->name, "Basics of Mathematics"); 
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) /**<enroll 20 students with random name,id, and grades>*/
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);/**<print out the course name, code, and the number of students and student info.>*/

  Student *student;
  student = top_student(MATH101); /**<find out the top students in MATH101>*/
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing); /**<find out students who pass the course>*/
  printf("\nTotal passing: %d\n", total_passing); 
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]); /**<print out students info who passed one by one >*/
  
  return 0;
}